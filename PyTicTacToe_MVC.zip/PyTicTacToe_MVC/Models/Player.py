class Player:
	def __init__(self, symbol):
		self.symbol = symbol
