from Controllers import GameController
from Models import Player, Board
from Views import View


p1_symbol = str(input("Choose symbol for Player1: "))
p2_symbol = str(input("Choose symbol for Player2: "))


def play_again():
    """Asks user input until Y or N. Returns True/False, in case of wrong input recursively calls itself."""
    restart = input("Would you like to go for another round?\nInsert Y for YES and N for NO: ")

    if restart.lower() == "y":
        return True
    elif restart.lower() == "n":
        print("Thank you for playing PyTicTacToe!")
        return False
    else:
        play_again()


def main():
    player1 = Player(p1_symbol)
    player2 = Player(p2_symbol)
    game_board = Board(player1, player2)
    view = View()
    controller = GameController(game_board, view)

    while controller.winner is None:
        controller.display_board()
        controller.handle_choice()
        controller.check_for_winner()
        controller.check_if_tie()
        controller.change_player()

    if play_again():
        controller.winner = None
        main()

main()